1. Ketika file di buka maka akan tampil bagian login yang berisikan username (email) dan passwordnya. Tetapi akan dikatakan dapat login bila sudah ada data email dan password di dalam databasenya.
2. Apabila tidak terdapat data di dalam database maka user harus register terlebih dahulu.
3. Ketika sudah login maka akan tampil bagian home yang berisikan student data sesuai dengan rolenya masing-masing. Karena setiap role memiliki akses yang berbeda. 
	Role : Admin , Aslab , dan Student
4. terdapat 2 Action di dalam table student, yaitu tombol edit, dan delete (dengan menggunakan modal). kedua action dapat diakses oleh Admin dan Aslab.
5. terdapat bagian About yang berisikan Coder's Profil
6. Logout berarti Sign Out dengan menggunakan modal

ps: nama database yang digunakan adalah mahasiswa (uts_soal01_web.sql)